/**
 * Created by Nick on 2/19/2016.
 */

package com.example.nick.quizapp;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.app.Activity;
import android.widget.EditText;

public class QuizFragment extends Fragment{

    private static EditText quizAnswer;

    QuizFragmentListener quizControl;

    public interface QuizFragmentListener
    {
        public void textAnswer(String ans);
    }

    @Override
    public void onAttach(Activity activity) {
        //super.onAttach(Activity activity);
        try
        {
            quizControl = (QuizFragmentListener) activity;
        }
        catch(ClassCastException c)
        {
            throw new ClassCastException(activity.toString());
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.quiz_fragment, container, false);

        quizAnswer = (EditText) view.findViewById(R.id.quizAnswer);
        final Button button = (Button) view.findViewById(R.id.button);

        button.setOnClickListener(
                new View.OnClickListener()
                {
                    public void onClick(View v)
                    {
                        buttonClicked(v);
                    }
                }
        );
        return view;
    }

    public void buttonClicked(View view)
    {
        quizControl.textAnswer(quizAnswer.getText().toString());
    }
}
