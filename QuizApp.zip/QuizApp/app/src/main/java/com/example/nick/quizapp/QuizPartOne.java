package com.example.nick.quizapp;

/**
 * Created by Nick on 2/19/2016.
 */




import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.app.Activity;
import android.widget.TextView;


public class QuizPartOne extends Activity
{
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.quiz_fragment);
        }

    public void playPressed(View view)
    {
        Intent intent = new Intent(this, QuizPartTwo.class);
        startActivity(intent);
        finish();

    }
}

