package com.example.nick.quizapp;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.app.Activity;
import android.widget.TextView;

/**
 * Created by Nick on 2/19/2016.
 */
public class QuizPartTwo extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_fragment_2);
    }

    public void playPressed(View view)
    {
        Intent intent = new Intent(this, ResultsActivity.class);
        startActivity(intent);
        finish();

    }
}
