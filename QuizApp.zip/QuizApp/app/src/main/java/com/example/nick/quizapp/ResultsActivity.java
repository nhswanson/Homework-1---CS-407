package com.example.nick.quizapp;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.app.Activity;
import android.widget.TextView;


/**
 * Created by Nick on 2/19/2016.
 */
public class ResultsActivity extends Activity {

    private static TextView quizAnswer;


    /*@Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle SavedInstanceState) {
        View view = inflater.inflate(R.layout.quiz_fragment, container, false);
        return view;
    }*/

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.results);
    }

    public void playPressed(View view)
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    public void exitApp(View view)
    {
        finish();
    }

    //Take in answers and display results
    public int setAnswer (String ans1, boolean ans2)
    {
        return 0;
    }
}
